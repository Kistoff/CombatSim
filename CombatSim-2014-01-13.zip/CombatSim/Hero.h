#ifndef HERO_H_INCLUDED
#define HERO_H_INCLUDED

#include <Mob.h>

class Hero
{
public:
    Hero()
    {
        level = 1;
        health = 25;
        mana = 20;
        strength = 5;
    }
    int attack(int heroAtt, int mobHP)
    {
        int remainingHP;
        remainingHP = mobHP - heroAtt;
    }
    int heal(int addHP)
    {
        health += addHP;
    }
    int getStrength()
    {
        return strength;
    }
    int getHealth()
    {
        return health;
    }
    int getMana()
    {
        return mana;
    }
    int getLevel()
    {
        return level;
    }
private:
    int level;
    int health;
    int mana;
    int strength;

    //int defense; too hard to implement now
};

#endif // HERO_H_INCLUDED
