#ifndef MOB_H_INCLUDED
#define MOB_H_INCLUDED

#include <Hero.h>

class Mob
{
public:
    Mob()
    {
        health = 50;
        mana = 20;
        strength = 15;
    }
    int attack(int mobAtt, int heroHP)
    {
        int remainingHP;
        remainingHP = heroHP - mobAtt;
    }
    int heal(int addHP)
    {
        health += addHP;
    }
    int getStrength()
    {
        return strength;
    }
    int getHealth()
    {
        return health;
    }
    int getMana()
    {
        return mana;
    }
private:
    int health;
    int mana;
    int strength;
    //int defense; too hard to implement now
};

#endif // MOB_H_INCLUDED
